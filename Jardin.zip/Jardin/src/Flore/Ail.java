package Flore;

public class Ail extends Vegetal{

	public Ail() {
		
		super();
		dessin[3] = "a";
		dessin[4] = "A";
		
	}

}
