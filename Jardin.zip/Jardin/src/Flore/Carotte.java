package Flore;

public class Carotte extends Vegetal{
	
	public Carotte() {
		
		super();
		dessin[3] = "c";
		dessin[4] = "C";
		
	}
		
}
