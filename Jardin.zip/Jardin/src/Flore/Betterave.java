package Flore;

public class Betterave extends Vegetal{

	public Betterave() {
		
		super();
		dessin[3] = "b";
		dessin[4] = "B";
		
	}

}
