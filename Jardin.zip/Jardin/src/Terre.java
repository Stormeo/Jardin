import java.util.Scanner;

public class Terre {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Jardin j = new Jardin(5,8); 
		System.out.println(j.toString());

		/*Scanner scanner = new Scanner(System.in);
        System.out.println("Choisissez une action : AVEC DES CHIFFRES");
        System.out.println("1. Semer une Graine");
        System.out.println("2. Recolter plante mature");
        System.out.println("3. Passer � la saison suivante");
        System.out.println("4. Quitter Application");
        int res = scanner.nextInt();*/
        
        
		
	}

}
